package Shapes;

public class Parallelogram extends Shapes {
    @Override
    float getArea() {
        return 0;
    }

    @Override
    float getPerimeter() {
        return 0;
    }

    float getArea(float base, float height) {
        return base * height;
    }

    float getPerimeter(float width, float length) {
        return (width * 2) + (length * 2);
    }
}
