package Shapes;

public class Triangle extends Shapes {
    @Override
    float getArea() {
        return 0;
    }

    @Override
    float getPerimeter() {
        return 0;
    }

    float getArea(float base, float height) {
        return (base * height) / 2;
    }

    float getPerimeter(float sideA, float sideB, float sideC) {
        return sideA + sideB + sideC;
    }
}
