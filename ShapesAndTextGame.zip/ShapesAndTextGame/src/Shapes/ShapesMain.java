package Shapes;

public class ShapesMain {
    Rectangle rectangle1 = new Rectangle();
    Pentagon pentagon1 = new Pentagon();
    Square square1 = new Square();
    Hexagon hexagon1 = new Hexagon();
    Triangle triangle1 = new Triangle();
    Parallelogram parallelogram1 = new Parallelogram();

    public static void main(String[] args) {
        float rectLength;

        System.out.println();
    }
}
