package Shapes;


public class Pentagon extends Shapes {
    @Override
    float getArea() {
        return 0;
    }

    @Override
    float getPerimeter() {
        return 0;
    }

    float getPerimeter(float sideLength) {
        return sideLength;
    }

    double getArea(float sideLength) {
        return (0.25 * Math.sqrt(5 * (5 + (2 * Math.sqrt(5)))) * Math.pow(sideLength, 2));
    }
}
