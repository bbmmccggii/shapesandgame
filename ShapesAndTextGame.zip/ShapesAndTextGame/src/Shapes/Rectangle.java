package Shapes;

public class Rectangle extends Shapes {
    @Override
    float getArea() {
        return 0;
    }

    @Override
    float getPerimeter() {
        return 0;
    }

    float getArea(float width, float length) {
        return (width * 2) * (length * 2);
    }

    float getPerimeter(float width, float height) {
        return (width * 2) + (height * 2);
    }
}
