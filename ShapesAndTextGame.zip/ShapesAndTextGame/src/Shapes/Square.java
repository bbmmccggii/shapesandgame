package Shapes;

public class Square extends Shapes {
    @Override
    float getArea() {
        return 0;
    }

    @Override
    float getPerimeter() {
        return 0;
    }

    float getArea(float width, float height) {
        return width * height;
    }

    float getPerimeter(float width, float height) {
        return (width * 2) + (height * 2);
    }
}
