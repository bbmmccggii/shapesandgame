package Shapes;

public abstract class Shapes {
    abstract float getArea();

    abstract float getPerimeter();
}

