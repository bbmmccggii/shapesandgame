package Shapes;

public class Hexagon extends Shapes {
    @Override
    float getArea() {
        return 0;
    }

    @Override
    float getPerimeter() {
        return 0;
    }

    double getArea(float sideLength) {
        return ((3 * (Math.sqrt(3))) / 2) * Math.pow(sideLength, 2);
    }

    float getPerimeter(float sideLength) {
        return sideLength * 6;
    }
}
